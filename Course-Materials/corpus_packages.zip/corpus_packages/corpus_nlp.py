#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Aug  9 06:22:09 2019

@author: kkyle2
"""
import glob
import spacy #import spacy
nlp = spacy.load("en_core_web_sm") #load the English model. This can be changed - just make sure that you download the appropriate model first

def tag(text,tp = "upos", lemma = True, lower = True, connect = "_",ignore = ["PUNCT","SPACE"]):
	
	#check to make sure a valid tag was chosen
	if tp not in ["penn","upos","dep"]:
		print("Please use a valid tag type: 'penn','upos', or 'dep'")
		return #exit the function
	
	else:
		doc = nlp(text) #use spacy to tokenize, lemmatize, pos tag, and parse the text
		text_list = []
		for token in doc:
			if token.pos_ in ignore: #if the universal POS tag is in our ignore list, then move to next word
				continue
			
			if lemma == True:
				word = token.lemma_
			else:
				if lower == True:
					word = token.text.lower()
				else:
					word = token.text
			
			if tp == None:
				text_list.append(word)
			
			else:
				if tp == "penn":
					tagged = token.tag_
				elif tp == "upos":
					tagged = token.pos_
				elif tp == "dep":
					tagged = token.dep_
			
			tagged_token = word + connect + tagged
			text_list.append(tagged_token)
		
		return(text_list)
		
		

def tag_corpus(dirname, ending = ".txt", tp = "upos", lemma = True, lower = True, connect = "_",ignore = ["PUNCT","SPACE"]):
	filenames = glob.glob(dirname + "/*" + ending) #gather all text names
	master_corpus = [] #holder for total corpus
	
	for filename in filenames: #iterate through corpus filenames
		raw_text = open(filename).read() #open each file
		master_corpus.append(tag(raw_text,tp,lemma,lower,connect,ignore)) #add the tagged text to the master list
	
	return(master_corpus) #return list
	

#tag_corpus("small_sample")
#sample = "This is a sample text.!?"
#tag(sample)
#tag(sample,tag="dep")
#tag(sample, tag = "penn")
#tag(sample,lemma = False)
#
#doc = nlp(sample)
#for x in doc:
#	print(x.text,x.lemma_x.tag_,x.pos_,x.dep_)
